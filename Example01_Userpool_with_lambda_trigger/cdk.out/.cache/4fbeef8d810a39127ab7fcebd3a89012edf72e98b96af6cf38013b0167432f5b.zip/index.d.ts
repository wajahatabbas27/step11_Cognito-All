declare const aws: any;
